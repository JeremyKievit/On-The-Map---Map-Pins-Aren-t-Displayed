//
//  FindLocationVC.swift
//  OnTheMap
//
//  Created by admin on 11/9/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class FindLocationVC: UIViewController {
    
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var linkField: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBAction func cancelPin(_ sender: Any) {
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
            
        }
    }
    
    @IBAction func findLocationButton(_ sender: Any) {
        self.setGeocoding(true)
        self.authenticateLocation { (success) in
            if success {
                self.findLocation()
            } else {
                self.setGeocoding(false)
            }
        }
    }
    
    
    func findLocation() {
        CLGeocoder().geocodeAddressString(self.locationField.text!) { (placemark, error) in
        guard error == nil else {
            DispatchQueue.main.async {
              let alert = UIAlertController(title: "Error", message: "Locator failed", preferredStyle: UIAlertController.Style.alert)
              alert.addAction(UIAlertAction(title: "Retry", style: UIAlertAction.Style.default, handler: { (action) in
               alert.dismiss(animated: true, completion: nil)}))
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
            
        Data.User.mapString = self.locationField.text!
        Data.User.coordinate = placemark!.first!.location?.coordinate
        print("coordinate data set in model")
        Data.User.latitude = (placemark?.first?.location?.coordinate.latitude)!
        Data.User.longitude = (placemark?.first?.location?.coordinate.longitude)!
            
        DispatchQueue.main.async {
            self.setGeocoding(false)
            self.performSegue(withIdentifier: "PostLocation", sender: self)
        }
        }
    }
    
    func authenticateLocation(completion: (_ success: Bool) -> Void) {
        if self.locationField.text?.isEmpty ?? true || self.locationField.text == "Location" {
            DispatchQueue.main.async {
              let alert = UIAlertController(title: "Error", message: "Please provide a location", preferredStyle: UIAlertController.Style.alert)
              alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
               alert.dismiss(animated: true, completion: nil)
              }))
              self.present(alert, animated: true, completion: nil)
            }
            completion(false)
            return
        } else if self.linkField.text?.isEmpty ?? true || self.linkField.text == "Link" {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Please include your Linkedin profile to proceed", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                alert.dismiss(animated: true, completion: nil)}))
                self.present(alert, animated: true, completion: nil)
            }
            completion(false)
            return
        }
        completion(true)
    }
    
    func setGeocoding(_ geocoding: Bool) {
        if geocoding {
            DispatchQueue.main.async {
                self.activityIndicator.startAnimating()
            }
        } else {
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
            }
        }
        locationField.isEnabled = !geocoding
        linkField.isEnabled = !geocoding
    }
}
