//
//  Table.swift
//  OnTheMap
//
//  Created by admin on 11/9/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class StudentTableVC: UIViewController {
    
    @IBOutlet weak var studentTableView: UITableView!
    
    static var tableData = [MKPointAnnotation]()
    
    func loadTableData() {
        OTMClient.getStudentLocations(completion: handleDataResponse(data:error:))
    }
    
    func handleDataResponse(data: [PinData]?, error: Error?) {
        guard let data = data else {
             DispatchQueue.main.async {
                 let alert = UIAlertController(title: "Error", message: "Could not access user data", preferredStyle: .alert)
                 alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                 self.present(alert, animated: true, completion: nil)
             }
             return
         }
         print("user data for table:", data)
         
         if error != nil {
             DispatchQueue.main.async {
                 let alert = UIAlertController(title: "Error accessing user data", message: "\(error!)", preferredStyle: .alert)
                 alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                 self.present(alert, animated: true, completion: nil)
             }
             return
         }
         
         let locations = data
         var annotations = [MKPointAnnotation]()
         
         for dictionary in locations {
             
             let lat = CLLocationDegrees(dictionary.latitude ?? 0)
             let long = CLLocationDegrees(dictionary.longitude ?? 0)
             let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
             
             
             let first = dictionary.firstName
             let last = dictionary.lastName
             let mediaURL = dictionary.mediaURL
             
             let annotation = MKPointAnnotation()
             annotation.coordinate = coordinate
             annotation.title = "\(first ?? "") \(last ?? "")"
             annotation.subtitle = mediaURL
             
             annotations.append(annotation)
         }
        
        Data.MKPointAnnotations = annotations
    }
}

extension StudentTableVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Data.MKPointAnnotations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell")!
        let annotation = Data.MKPointAnnotations[indexPath.row]
        
        cell.textLabel!.text = annotation.title
        cell.detailTextLabel!.text = annotation.subtitle

        return cell
    }
    
}
