//
//  StudentLocationsResponse.swift
//  OnTheMap
//
//  Created by admin on 11/13/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation

struct StudentLocationsResponse {
  
}
